
# ====================================================================
# QUESTION 18
#
# Perform unsharp masking and high-boost filtering.
# ====================================================================
import cv2
import matplotlib.pyplot as plt

# Read the image
image = cv2.imread("sample.jpeg")   # Replace with your image path

# Convert BGR to RGB
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# -----------------------------
# Unsharp Masking
# -----------------------------
blur = cv2.GaussianBlur(image_rgb, (5,5), 0)
unsharp = cv2.addWeighted(image_rgb, 1.5, blur, -0.5, 0)

# -----------------------------
# High-Boost Filtering
# -----------------------------
A = 2.0  # High-boost factor (A > 1)

high_boost = cv2.addWeighted(image_rgb, A, blur, -(A-1), 0)

# -----------------------------
# Display Results
# -----------------------------
plt.figure(figsize=(15,5))

plt.subplot(1,3,1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(1,3,2)
plt.imshow(unsharp)
plt.title("Unsharp Masking")
plt.axis("off")

plt.subplot(1,3,3)
plt.imshow(high_boost)
plt.title("High-Boost Filter")
plt.axis("off")

plt.tight_layout()
plt.show()

"""Experiment 18: Unsharp Masking and High-Boost Filtering

Aim:
To sharpen an image using Unsharp Masking and High-Boost Filtering.

Concept:
Both techniques improve image sharpness by enhancing edges.

Unsharp Masking: A blurred image is subtracted from the original image to highlight edges and make the image sharper.
High-Boost Filtering: It is an improved version of unsharp masking that retains more of the original image while providing stronger sharpening. It uses a boost factor A > 1.

Functions Used:

blur = cv2.GaussianBlur(image, (5,5), 0)

unsharp = cv2.addWeighted(image, 1.5, blur, -0.5, 0)

high_boost = cv2.addWeighted(image, 2.0, blur, -1.0, 0)

Result:
Unsharp masking enhances image edges, while High-Boost filtering produces stronger sharpening and preserves more image details.

19. Apply gradient operators (Sobel, Prewitt) for edge
detection
"""

