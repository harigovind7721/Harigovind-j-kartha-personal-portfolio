
# ====================================================================
# QUESTION 11
#
# Perform piecewise linear transformations (contrast stretching,
# thresholding).
# ====================================================================
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Read image in grayscale
img = cv2.imread("sample.jpeg", 0)

# Contrast Stretching
contrast = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX)

# Thresholding
threshold_value = 128
_, threshold = cv2.threshold(img, threshold_value, 255, cv2.THRESH_BINARY)

# Display images
plt.figure(figsize=(15,5))

plt.subplot(1,3,1)
plt.imshow(img, cmap='gray')
plt.title("Original Image")
plt.axis("off")

plt.subplot(1,3,2)
plt.imshow(contrast, cmap='gray')
plt.title("Contrast Stretching")
plt.axis("off")

plt.subplot(1,3,3)
plt.imshow(threshold, cmap='gray')
plt.title("Thresholding")
plt.axis("off")

plt.show()

"""1. Contrast Stretching

Contrast stretching increases the range of pixel intensities.

Before:

Pixel values may lie between 50 and 180.
Image looks dull.

After:

Pixel values are stretched to 0–255.
Image looks sharper and clearer.

2. Thresholding

Thresholding converts a grayscale image into a binary image.

Rule:

If pixel > 128 → 255 (White)

If pixel ≤ 128 → 0 (Black)

Example:

Algorithm

Contrast Stretching

Read the image.

Find minimum and maximum intensity values.

Stretch the values to the full range (0–255).

Display the enhanced image.

Thresholding

Read the grayscale image.

Choose a threshold value (128).

Set pixels above the threshold to white.

Set pixels below the threshold to black.

Display the binary image.

12. Perform Histogram Equalization and Compare Results
"""

