
# ====================================================================
# QUESTION 4 (copy)
#
# Compute and visualize adjacency and connectivity in a binary image.
# (Second copy of the same code in digi_4.py)
# ====================================================================
import numpy as np
import matplotlib.pyplot as plt

img = np.array([
    [0,0,0,0,0],
    [0,1,1,0,0],
    [0,1,1,1,0],
    [0,0,1,0,0],
    [0,0,0,0,0]
])

plt.imshow(img, cmap='gray')
plt.title("Binary Image")
plt.show()

# Pixel position
row = 2
col = 2

print("Selected Pixel:", img[row, col])

# 4-neighbors
print("\n4-Adjacency:")
print("Top:", img[row-1, col])
print("Bottom:", img[row+1, col])
print("Left:", img[row, col-1])
print("Right:", img[row, col+1])

# 8-neighbors
print("\n8-Adjacency:")
for i in range(row-1, row+2):
    for j in range(col-1, col+2):
        if (i, j) != (row, col):
            print(f"Neighbor ({i},{j}) =", img[i, j])

