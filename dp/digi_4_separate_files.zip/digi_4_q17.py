
# ====================================================================
# QUESTION 17
#
# Sharpening filters using Laplacian.
# ====================================================================
import cv2
import matplotlib.pyplot as plt

# Read the image
image = cv2.imread("sample.jpeg")  # Replace with your image path

# Convert BGR to RGB
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Convert to Grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Laplacian Filter
laplacian = cv2.Laplacian(gray, cv2.CV_64F)
laplacian = cv2.convertScaleAbs(laplacian)

# Display Results
plt.figure(figsize=(12,4))

plt.subplot(1,3,1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

plt.subplot(1,3,2)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale Image")
plt.axis("off")

plt.subplot(1,3,3)
plt.imshow(laplacian, cmap="gray")
plt.title("Laplacian Filter")
plt.axis("off")

plt.tight_layout()
plt.show()

"""Experiment 17: Sharpening Filter using Laplacian

Aim:
To sharpen an image using the Laplacian filter.

Concept:
Sharpening enhances the edges and fine details of an image. The Laplacian filter is an edge detection filter that highlights regions where pixel intensity changes rapidly. This makes the edges more visible and improves image sharpness.

Function Used:

cv2.Laplacian(gray, cv2.CV_64F)

Result:
The Laplacian filter enhances image edges by detecting rapid intensity changes, producing a sharper image with more visible details.

18. Perform unsharp masking and high-boost filtering.
"""

