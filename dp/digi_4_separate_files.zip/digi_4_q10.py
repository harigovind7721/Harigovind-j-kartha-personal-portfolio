
# ====================================================================
# QUESTION 10
#
# Power-law (gamma) transformation for different gamma values.
# ====================================================================
"""10. Pwer-law (gamma) transformation for different gamma
values.

Formula
s=c⋅r
γ

Where:

r = Input pixel value (normalized between 0 and 1)

s = Output pixel value

c = Constant (usually 1)

γ (gamma) = Gamma value
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

# Read image
img = cv2.imread("sample.jpeg")

# Convert BGR to RGB
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

# Normalize image to range [0,1]
img_norm = img / 255.0

# Different gamma values
gamma_values = [0.5, 1.0, 2.0]

plt.figure(figsize=(15,5))

# Original image
plt.subplot(1,4,1)
plt.imshow(img)
plt.title("Original")
plt.axis("off")

# Apply gamma correction
for i, gamma in enumerate(gamma_values):
    gamma_img = np.power(img_norm, gamma) #Apply Power Law (Output=Input^γ)
    gamma_img = np.uint8(gamma_img * 255) #Convert Back to 0–255 Range

#Displays each transformed image.
    plt.subplot(1,4,i+2)
    plt.imshow(gamma_img)
    plt.title(f"Gamma = {gamma}")
    plt.axis("off")
#Prevents titles and images from overlapping.
plt.tight_layout()
plt.show()

"""Simple Explanation

Gamma transformation changes the brightness of an image.

Gamma (γ)	Effect

γ < 1 (0.5)	Brightens image

γ = 1	Original image

γ > 1 (2.0)	Darkens image

Analysis

Gamma = 0.5

Dark pixels become brighter.

Useful for dark images.

Gamma = 1

No change.

Gamma = 2

Bright pixels are reduced.

Image appears darker.

Example

If a pixel value is 0.5:

γ = 0.5 → 0.5^
0.5=0.707 (brighter)

γ = 1 → 0.5^1
=0.5 (same)

γ = 2 → 0.5^
2
=0.25 (darker)

Algorithm

Read the image

Normalize pixel values to [0,1].

Choose different gamma values.

Apply s=r^γ

Convert back to 0–255 range.

Display the transformed images.

Result

Power-law (gamma) transformation was applied successfully for different gamma values. Images became brighter for γ < 1 and darker for γ > 1, demonstrating contrast and brightness adjustment through gamma correction.

11. Perform Piecewise Linear Transformations (Contrast Stretching and Thresholding)
"""

